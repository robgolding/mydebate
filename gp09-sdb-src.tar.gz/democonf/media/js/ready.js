// 
// Author: Rob Golding
// Project: myDebate
// Group: gp09-sdb
// 

// call the ready function when the page loads.

// very important!!
$(document).ready(function() {
	ready();	
});

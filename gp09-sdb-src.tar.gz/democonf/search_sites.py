## 
## Author: Rob Golding
## Project: myDebate
## Group: gp09-sdb
## 

import haystack

haystack.autodiscover()

## 
## Author: Rob Golding
## Project: myDebate
## Group: gp09-sdb
## 

from django.conf.urls.defaults import *

import views

urlpatterns = patterns('',
	
)

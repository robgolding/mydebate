## 
## Author: Rob Golding
## Project: myDebate
## Group: gp09-sdb
## 

import os

WORKING_COPY = True
PATH = os.path.abspath(os.path.dirname(__file__))

DATABASE_ENGINE = 'sqlite3'
DATABASE_NAME = os.path.join(PATH, 'dev.db')

MEDIA_ROOT = os.path.join(PATH, 'media')
MEDIA_URL = '/media/'

LOGIN_URL = '/accounts/login/'

LOGOUT_URL = '/accounts/logout/'

LOGIN_REDIRECT_URL = '/'

LOGOUT_REDIRECT_URL = '/'

from django.db import models

"""No models for the core app."""

## 
## Author: Rob Golding
## Project: myDebate
## Group: gp09-sdb
## 

from django.contrib import admin

from models import Profile

admin.site.register(Profile)
